package com.example.convertpdf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.pdf.PdfDocument;
import android.icu.util.LocaleData;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.pdf.PdfDocument.PageInfo;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String[] header = {"Id", "Nombre", "Apellido"};
    private String shorText = "Hola 2222222";
    private String longText = "Nunca consideres el estudio como una obligación, sino como una ";
    private TemplatePDF templatePDF;
    private Button button;
    private ImageView ivIcono;
    private final int RC_PERMISSION_WRITE_EXTERNAL_STORAGE = 100;
    private StorageReference mStorageRef;
    public static StorageReference riversRef;
    Image img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        ivIcono = findViewById(R.id.ivIcono);
        mStorageRef = FirebaseStorage.getInstance().getReference();

        getImg();

        requestWriteExternalStoragePermission();
        requestReadExternalStoragePermission();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                templatePDF = new TemplatePDF(getApplicationContext(), img);
                templatePDF.openDocument();
                templatePDF.addMetaData("Clientes", "Ventas", "MArines");
                templatePDF.addTitles("Tienda de Tambo", "Clientes", "6/12/2019");
                templatePDF.addParagraph(shorText);
                templatePDF.addParagraph(longText);
                templatePDF.createTable(header, getClientes());
                templatePDF.addImage();
                templatePDF.addParagraph("dsfsdfsdfsd");
                templatePDF.closeDocument();
                pdfView();
                guardarPdf();
            }
        });
    }

    private void getImg(){

        //Bitmap bm = BitmapFactory.decodeResource(getResources(), getResources().getDrawable(ivIcono));
        Bitmap bitmap = ((BitmapDrawable)ivIcono.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        img= null;
        byte[] byteArray = stream.toByteArray();
        try {
            img = Image.getInstance(byteArray);
        } catch (BadElementException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarPdf(){
        //Uri file = Uri.fromFile(new File("path/to/images/rivers.jpg"));
        Uri file = Uri.fromFile(templatePDF.pdfFile);
        riversRef = mStorageRef.child("PDF/TemplatePDF.pdf");

        riversRef.putFile(file)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // Get a URL to the uploaded content
                        Uri downloadUrl = taskSnapshot.getUploadSessionUri();

                        riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String url = uri.toString();
                                /*Upload upload = new Upload(et_localization, url);
                                String uploadId = mDataBaseRef.push().getKey();
                                mDataBaseRef.child(uploadId).setValue(upload);*/
                            }
                        });

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        // ...
                        Log.e("Error", exception.toString());
                    }
                });
    }

    public void pdfView(){
        templatePDF.appViewPdf(this);
        // leer y escribir en el dispositivo
    }

    public ArrayList<String[]> getClientes(){
        ArrayList<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"1","Monica","Jaqueline"});
        rows.add(new String[]{"2","Monica","Flaquita Sexy"});
        rows.add(new String[]{"3","Monica","la mas hermosa"});
        return rows;
    }

    private void requestWriteExternalStoragePermission() {
        // Should we show an explanation?
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Inform and request")
                    .setMessage("You need to enable permissions, bla bla bla")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, RC_PERMISSION_WRITE_EXTERNAL_STORAGE);
                        }
                    })
                    .show();
        } else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, RC_PERMISSION_WRITE_EXTERNAL_STORAGE);
        }
    }

    public void requestReadExternalStoragePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Inform and request")
                    .setMessage("You need to enable permissions, bla bla bla")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, RC_PERMISSION_WRITE_EXTERNAL_STORAGE);
                        }
                    })
                    .show();
        } else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, RC_PERMISSION_WRITE_EXTERNAL_STORAGE);
        }
    }
}

