package com.example.convertpdf;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfIsoConformanceException;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class TemplatePDF {
    private Context context;
    public File pdfFile;
    private Document document;
    private PdfWriter pdfWriter;
    private Paragraph paragraph; // parrafo
    private Image ivPrueba;

    // formatos
    private Font fTitle = new Font(Font.FontFamily.TIMES_ROMAN, 20, Font.BOLD);
    private Font fSubtitle = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
    private Font fText = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
    private Font fHighText = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD, BaseColor.RED);

    public TemplatePDF(Context context, Image ivPrueba) {
        this.context = context;
        this.ivPrueba = ivPrueba;
    }

    private void createFile(){
        // DIRECCIÓN DE SD - NOMBRE DE FOLDER
        File folder = new File(Environment.getExternalStorageDirectory().toString(), "PDF");
        //File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) , "PDF");


        // verificamos si el folder existe
        if(!folder.exists())
            folder.mkdir();

        pdfFile = new File(folder, "TemplatePDF3.pdf");
        // abrimos para
    }

    // cuando se agregan valores al pdf son como metadatos
    public void openDocument(){
        createFile();
        try{
            document = new Document(PageSize.A4);// Creamos el documento
            pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
            // abrimos documento
            document.open();
        }catch (Exception e){
            Log.e("opendocument", e.toString());
        }
    }

    public void closeDocument(){
        document.close();
    }

    public void addMetaData(String title, String subject, String author){
        document.addTitle(title);
        document.addSubject(subject);
        document.addAuthor(author);
    }

    public void addTitles(String title, String subTitle, String date){
        try{
            paragraph = new Paragraph();
            addChildP(new Paragraph(title, fTitle));
            addChildP(new Paragraph(subTitle, fSubtitle));
            addChildP(new Paragraph("Generado: "+ date, fHighText));
            paragraph.setSpacingAfter(30);
            document.add(paragraph);
        }catch (Exception e){
            Log.e("adtitles ", e.toString());
        }

    }

    //
    private void addChildP(Paragraph childParagraph){
        childParagraph.setAlignment(Element.ALIGN_CENTER); // ALINEADO AL CENTRO
    }

    public void addParagraph(String text){
        try{
            paragraph = new Paragraph(text, fText);
            paragraph.setSpacingAfter(5);
            paragraph.setSpacingBefore(5);
            document.add(paragraph);
        }catch (Exception e){
            Log.e("adtitles ", e.toString());
        }
    }

    public void addImage(){
        try{
           /* paragraph = new Paragraph(ivPrueba);
            paragraph.setSpacingAfter(5);
            paragraph.setSpacingBefore(5);
            document.add(paragraph);*/
            document.add((Element) ivPrueba);
        }catch (Exception e){
            Log.e("adtitles ", e.toString());
        }
    }

    public void createTable(String[] header, ArrayList<String[]> clients){
        paragraph = new Paragraph();
        paragraph.setFont(fText);// Agregamos fotmato que irá dentro de la tabla
        PdfPTable pdfPTable = new PdfPTable(header.length);// número de collumnas de la tabla
        pdfPTable.setWidthPercentage(100);// en porcentajes el ancho de la tabla
        pdfPTable.setSpacingBefore(20);
        PdfPCell pdfPCell; // creamos celdas
        int index = 0;
        // lenamos nuestro encabezado
        while (index < header.length){
            //
            pdfPCell = new PdfPCell(new Phrase(header[index++], fSubtitle));
            pdfPCell.setHorizontalAlignment(Element.ALIGN_CENTER);// alinear las celdas alineados
            pdfPCell.setBackgroundColor(BaseColor.GREEN);
            pdfPTable.addCell(pdfPCell);// agregamos la celda a la tabla
        }

        // clientes son las filas
        for(int indexR = 0; indexR< clients.size(); indexR++){
            // obtenemos la fila
            String[] row = clients.get(indexR);
            // recorremos las columnas
            for(int indexC = 0; indexC<clients.size(); indexC++){
                pdfPCell = new PdfPCell(new Phrase(row[indexC]));
                pdfPCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfPCell.setFixedHeight(40);
                pdfPTable.addCell(pdfPCell);
            }
        }
        // agregamos la tabla al parrafo
        paragraph.add(pdfPTable);
        try{
            document.add(paragraph);// agregamos parrafo al documento
        }catch (Exception e){
        Log.e("createTable ", e.toString());
        }

    }

    /*public void viewPdf(){
        Intent i = new Intent(context, "CLASE QUE IMPLEMENTA LA LIBRERIA");
        i.putExtra("path", pdfFile.getAbsolutePath());
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }*/

    public void appViewPdf(Activity activity){
        if(Build.VERSION.SDK_INT>=24){
            try{
                Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                m.invoke(null);
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        if(pdfFile.exists()){
            Uri uri = Uri.fromFile(pdfFile);//
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/pdf");
            try{
                activity.startActivity(i);
            }catch (ActivityNotFoundException e){
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.adobe.reader")));
                Log.e("appViewPdf", e.toString());
                Toast.makeText(activity.getApplicationContext(), "no cuentas con una aplicación para visualizar PDF", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(activity, "no se encontró el documento", Toast.LENGTH_SHORT).show();
        }
    }
}
